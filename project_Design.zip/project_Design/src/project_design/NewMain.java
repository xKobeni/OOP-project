package project_design;

public class NewMain {

    public static void main(String[] args) {
        Login logFrame = new Login(); 
        //database_server men = new database_server(); 
        logFrame.setVisible(true);
        logFrame.pack();
        logFrame.setLocationRelativeTo(null);
    }
    
}
